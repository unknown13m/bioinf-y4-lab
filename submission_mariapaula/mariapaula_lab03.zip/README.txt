Autori:
Maria Paula (GitHub handle: mariapaula)

Disclosure AI:
Am folosit chatGPT doar pentru explicații de comandă, debugging în terminal și lamuriri despre structurarea fisierelor. 
Toate scripturile le-am scris, verificat și rulat manual în codespaces. 
Am verificat rezultatele de la fiecare pas prin rulare în terminal.

Sursa FASTQ:
your_reads.fastq a fost generat în cadrul lab-ului după instrucțiunile din cerinta (fisierul exemplu pentru exercitiu).
